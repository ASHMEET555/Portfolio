'use client';

import { useState, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import HolographicCard from './advanced/HolographicCard';

interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  longDescription: string;
  problem: string;
  solution: string;
  setup: string[];
  technologies: string[];
  image: string;
  demoUrl?: string;
  githubUrl?: string;
  status: 'completed' | 'in-progress' | 'research';
  featured: boolean;
  metrics: {
    performance: string;
    impact: string;
    users?: string;
  };
  year: string;
}

const ProjectsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [filter, setFilter] = useState('all');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const categories = [
    { id: 'all', label: 'ALL_PROJECTS', icon: '🌐' },
    { id: 'research', label: 'RESEARCH', icon: '🔬' }
  ];

  const projects: Project[] = [
    {
      id: 'medinodus',
      title: 'MediNodus - Medical AI',
      category: 'ai-ml',
      description: 'Privacy-first AI medical assistant using 4B-parameter vision-language model with 100% local processing.',
      longDescription: 'An advanced AI medical assistant that operates entirely offline, ensuring complete privacy. Uses a quantized 4B-parameter vision-language model (MedGemma) to process medical images, extract lab values, and generate patient-friendly summaries without any external API calls.',
      problem: 'Medical AI systems often rely on cloud-based processing, raising privacy concerns. Patients need accessible medical information without compromising sensitive health data.',
      solution: 'Engineered a privacy-first system using 4-bit quantization for local processing. Built diagnostic pipeline for image parsing, lab value extraction, and real-time drug safety system integrated with OpenFDA database.',
      setup: [
        'Clone repository: git clone https://github.com/ASHMEET555/medinodus',
        'Install dependencies: pip install -r requirements.txt',
        'Download MedGemma model (4B params)',
        'Configure MongoDB connection',
        'Run: docker-compose up',
        'Access API at http://localhost:8000'
      ],
      technologies: ['FastAPI', 'MongoDB', 'MedGemma', 'LangChain', 'Docker', 'Python', '4-bit Quantization'],
      image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=400&fit=crop',
      demoUrl: '#',
      githubUrl: 'https://github.com/ASHMEET555',
      status: 'completed',
      featured: true,
      metrics: {
        performance: '2000-token summaries',
        impact: '100% local processing',
        users: 'Zero API calls'
      },
      year: 'Dec 2025 - Jan 2026'
    },
    {
      id: 'flashpoint',
      title: 'FlashPoint - Real-Time Intelligence',
      category: 'ai-ml',
      description: 'Distributed real-time intelligence platform with Live RAG system aggregating data from 50+ sources.',
      longDescription: 'A sophisticated real-time intelligence platform that aggregates streaming data from multiple sources, applies deduplication, and provides AI-powered insights through a Live RAG system. Features asynchronous processing, vector search, and automated PDF report generation.',
      problem: 'Information overload from multiple sources makes real-time decision-making difficult. Traditional systems struggle with data deduplication and providing contextual AI responses.',
      solution: 'Architected distributed pipeline using Celery workers and Redis for data aggregation. Implemented Live RAG with Qdrant vector database and LangChain for grounded LLM responses. Built SSE streaming dashboard with interactive maps and NER analysis.',
      setup: [
        'Clone repository: git clone https://github.com/ASHMEET555/flashpoint',
        'Install dependencies: pip install -r requirements.txt',
        'Set up PostgreSQL and TimescaleDB',
        'Configure Qdrant vector database',
        'Set up Redis and Celery workers',
        'Run migrations: python manage.py migrate',
        'Start workers: celery -A flashpoint worker',
        'Run server: uvicorn main:app --reload'
      ],
      technologies: ['FastAPI', 'Qdrant', 'LangChain', 'PostgreSQL', 'TimescaleDB', 'Celery', 'Redis', 'SentenceTransformers', 'spaCy', 'Gemini API'],
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop',
      demoUrl: '#',
      githubUrl: 'https://github.com/ASHMEET555',
      status: 'completed',
      featured: true,
      metrics: {
        performance: '50+ data sources',
        impact: 'Real-time streaming',
        users: 'Live RAG system'
      },
      year: 'Jan 2026'
    },
    {
      id: 'chainaudit',
      title: 'ChainAudit AI - Blockchain Fraud Detection',
      category: 'ai-ml',
      description: 'Multi-domain AI fraud detection platform with immutable on-chain audit trails on Ethereum.',
      longDescription: 'Advanced fraud detection system combining AI/ML algorithms with blockchain technology. Analyzes transactions across banking, e-commerce, insurance, and Ethereum networks. Stores cryptographic fraud proofs on-chain while maintaining privacy through off-chain AI processing.',
      problem: 'Fraud detection systems lack transparency and immutable audit trails. Balancing privacy requirements with verification needs is challenging.',
      solution: 'Built multi-domain AI platform with separate models for different transaction types. Implemented hybrid architecture: off-chain AI processing for privacy and low-latency, on-chain verification for immutability. Smart contracts store cryptographic proofs on Ethereum.',
      setup: [
        'Clone repository: git clone https://github.com/ASHMEET555/chainaudit',
        'Install dependencies: pip install -r requirements.txt',
        'Set up Ethereum node or use Infura',
        'Deploy smart contracts: truffle migrate',
        'Configure Web3 connection',
        'Run FastAPI server: uvicorn main:app --reload',
        'Access demo at http://localhost:8000/demo'
      ],
      technologies: ['Python', 'Ethereum', 'Solidity', 'Web3.py', 'FastAPI', 'Machine Learning', 'Smart Contracts'],
      image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=600&h=400&fit=crop',
      demoUrl: 'https://chainaudit-demo.com',
      githubUrl: 'https://github.com/ASHMEET555',
      status: 'completed',
      featured: true,
      metrics: {
        performance: 'Multi-domain AI',
        impact: 'Immutable audit trail',
        users: 'On-chain verification'
      },
      year: 'Feb 2026'
    },
    {
      id: 'triage',
      title: 'Emergency Triage Risk Stratification',
      category: 'research',
      description: 'Multimodal ensemble system stratifying 58,000+ NHAMCS patient records into 3 risk tiers.',
      longDescription: 'Research project developing a multimodal machine learning system for emergency department triage. Combines physiological tabular data with NLP analysis of patient complaints to stratify risk levels. Uses ensemble methods including XGBoost, LightGBM, and ClinicalBERT.',
      problem: 'Emergency departments need accurate patient risk stratification to prioritize care. Undertriage can be life-threatening, while overtriage wastes resources.',
      solution: 'Engineered ordinal-aware meta-learner pipeline combining tabular and text data. Achieved 0.65 urgent-class recall to reduce undertriage. Used SHAP and LIME for clinical explainability, ensuring medical professionals can understand model decisions.',
      setup: [
        'Clone repository: git clone https://github.com/ASHMEET555/emergency-triage',
        'Download NHAMCS dataset',
        'Install dependencies: pip install -r requirements.txt',
        'Preprocess data: python preprocess.py',
        'Train models: python train_ensemble.py',
        'Evaluate: python evaluate.py',
        'View demo: python app.py'
      ],
      technologies: ['Python', 'XGBoost', 'LightGBM', 'ClinicalBERT', 'NLP', 'SHAP', 'LIME', 'Scikit-learn', 'Pandas'],
      image: 'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=600&h=400&fit=crop',
      demoUrl: 'https://triage-demo.com',
      githubUrl: 'https://github.com/ASHMEET555',
      status: 'research',
      featured: false,
      metrics: {
        performance: '0.65 Urgent recall',
        impact: '58,000+ records',
        users: 'Clinical explainability'
      },
      year: 'April 2026'
    }
  ];

  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);

  const featuredProjects = projects.filter(project => project.featured);

  return (
    <section ref={ref} id="projects" className="py-32">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl text-cyberpunk-text text-glow-red mb-6">
            &lt;PROJECT_ARCHIVE/&gt;
          </h2>
          <p className="text-xl text-cyberpunk-text-dim max-w-3xl mx-auto">
            AI/ML solutions bridging research and real-world impact
          </p>
        </motion.div>

        {/* Filter Navigation */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-4 mb-16"
        >
          {categories.map((category) => (
            <motion.button
              key={category.id}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setFilter(category.id)}
              className={`px-6 py-3 border tracking-wider transition-all duration-300 relative overflow-hidden ${
                filter === category.id
                  ? 'border-cyberpunk-red bg-cyberpunk-red text-cyberpunk-text'
                  : 'border-cyberpunk-red/30 text-cyberpunk-text-dim hover:border-cyberpunk-red hover:text-cyberpunk-red'
              }`}
            >
              <span className="relative z-10 flex items-center space-x-2">
                <span>{category.icon}</span>
                <span>{category.label}</span>
              </span>
              
              {filter === category.id && (
                <motion.div
                  layoutId="activeFilter"
                  className="absolute inset-0 bg-cyberpunk-red"
                  initial={false}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              )}
            </motion.button>
          ))}
        </motion.div>

        {/* Featured Projects */}
        {filter === 'all' && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mb-20"
          >
            <h3 className="text-2xl text-cyberpunk-red tracking-wider mb-8 text-center">
              FEATURED_PROJECTS
            </h3>
            
            <div className="grid lg:grid-cols-3 gap-8">
              {featuredProjects.map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 50 }}
                  animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  whileHover={{ y: -10 }}
                >
                  <HolographicCard 
                    className="h-full cursor-pointer overflow-hidden"
                    onClick={() => setSelectedProject(project)}
                  >
                    <div className="relative">
                      <div className="relative h-48 overflow-hidden">
                        <ImageWithFallback
                          src={project.image}
                          alt={project.title}
                          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-cyberpunk-dark to-transparent"></div>
                        
                        {/* Status indicator */}
                        <div className={`absolute top-4 right-4 px-2 py-1 text-xs tracking-wider border ${
                          project.status === 'completed' ? 'border-green-400 text-green-400 bg-green-400/10' :
                          project.status === 'in-progress' ? 'border-yellow-400 text-yellow-400 bg-yellow-400/10' :
                          'border-blue-400 text-blue-400 bg-blue-400/10'
                        }`}>
                          {project.status.toUpperCase().replace('-', '_')}
                        </div>

                        {/* Featured badge */}
                        <div className="absolute top-4 left-4 px-2 py-1 text-xs tracking-wider border border-cyberpunk-red text-cyberpunk-red bg-cyberpunk-red/10">
                          FEATURED
                        </div>
                      </div>
                      
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-xl text-cyberpunk-red">{project.title}</h4>
                          <span className="text-sm text-cyberpunk-text-dim">{project.year.split(' ')[0]}</span>
                        </div>
                        
                        <p className="text-cyberpunk-text-dim text-sm mb-4 leading-relaxed">
                          {project.description}
                        </p>
                        
                        {/* Technologies */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          {project.technologies.slice(0, 3).map((tech) => (
                            <span
                              key={tech}
                              className="px-2 py-1 text-xs border border-cyberpunk-red/30 text-cyberpunk-red bg-cyberpunk-red/5"
                            >
                              {tech}
                            </span>
                          ))}
                          {project.technologies.length > 3 && (
                            <span className="px-2 py-1 text-xs text-cyberpunk-text-dim">
                              +{project.technologies.length - 3}
                            </span>
                          )}
                        </div>
                        
                        {/* Metrics */}
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <div className="text-cyberpunk-red text-sm">{project.metrics.performance}</div>
                            <div className="text-xs text-cyberpunk-text-dim">Performance</div>
                          </div>
                          <div>
                            <div className="text-cyberpunk-red text-sm">{project.metrics.impact}</div>
                            <div className="text-xs text-cyberpunk-text-dim">Impact</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </HolographicCard>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* All Projects Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={filter}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="grid md:grid-cols-2 lg:grid-cols-2 gap-8"
            >
              {filteredProjects.map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                >
                  <HolographicCard 
                    className="h-full cursor-pointer overflow-hidden"
                    onClick={() => setSelectedProject(project)}
                  >
                    <div className="relative">
                      <div className="relative h-40 overflow-hidden">
                        <ImageWithFallback
                          src={project.image}
                          alt={project.title}
                          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-cyberpunk-dark to-transparent"></div>
                        
                        {/* Status indicator */}
                        <div className={`absolute top-3 right-3 px-2 py-1 text-xs tracking-wider border ${
                          project.status === 'completed' ? 'border-green-400 text-green-400 bg-green-400/10' :
                          project.status === 'in-progress' ? 'border-yellow-400 text-yellow-400 bg-yellow-400/10' :
                          'border-blue-400 text-blue-400 bg-blue-400/10'
                        }`}>
                          {project.status.toUpperCase().replace('-', '_')}
                        </div>
                      </div>
                      
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg text-cyberpunk-red">{project.title}</h4>
                          <span className="text-xs text-cyberpunk-text-dim">{project.year.split(' ')[0]}</span>
                        </div>
                        
                        <p className="text-cyberpunk-text-dim text-sm mb-3 leading-relaxed line-clamp-2">
                          {project.description}
                        </p>
                        
                        {/* Technologies */}
                        <div className="flex flex-wrap gap-1 mb-3">
                          {project.technologies.slice(0, 3).map((tech) => (
                            <span
                              key={tech}
                              className="px-2 py-1 text-xs border border-cyberpunk-red/30 text-cyberpunk-red bg-cyberpunk-red/5"
                            >
                              {tech}
                            </span>
                          ))}
                          {project.technologies.length > 3 && (
                            <span className="px-2 py-1 text-xs text-cyberpunk-text-dim">
                              +{project.technologies.length - 3}
                            </span>
                          )}
                        </div>
                        
                        {/* Quick metrics */}
                        <div className="text-center">
                          <div className="text-cyberpunk-red text-sm">{project.metrics.performance}</div>
                          <div className="text-xs text-cyberpunk-text-dim">Performance</div>
                        </div>
                      </div>
                    </div>
                  </HolographicCard>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        </motion.div>

        {/* Project Detail Modal */}
        <AnimatePresence>
          {selectedProject && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-cyberpunk-dark/90 backdrop-blur-sm z-50 flex items-center justify-center p-6 overflow-y-auto"
              onClick={() => setSelectedProject(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.8, y: 50 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: 50 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="bg-cyberpunk-dark border border-cyberpunk-red max-w-5xl w-full max-h-[90vh] overflow-y-auto my-8"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="relative">
                  {/* Header */}
                  <div className="relative h-64 overflow-hidden">
                    <ImageWithFallback
                      src={selectedProject.image}
                      alt={selectedProject.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-cyberpunk-dark via-transparent to-cyberpunk-dark/50"></div>
                    
                    <button
                      onClick={() => setSelectedProject(null)}
                      className="absolute top-4 right-4 w-10 h-10 border border-cyberpunk-red text-cyberpunk-red hover:bg-cyberpunk-red hover:text-cyberpunk-text transition-colors duration-200"
                    >
                      ✕
                    </button>
                    
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-3xl text-cyberpunk-red mb-2">{selectedProject.title}</h3>
                      <div className="flex items-center space-x-4">
                        <span className="text-cyberpunk-text-dim">{selectedProject.year}</span>
                        <span className={`px-2 py-1 text-xs tracking-wider border ${
                          selectedProject.status === 'completed' ? 'border-green-400 text-green-400' :
                          selectedProject.status === 'in-progress' ? 'border-yellow-400 text-yellow-400' :
                          'border-blue-400 text-blue-400'
                        }`}>
                          {selectedProject.status.toUpperCase().replace('-', '_')}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Content */}
                  <div className="p-8">
                    <div className="space-y-8">
                      {/* Overview */}
                      <div>
                        <h4 className="text-xl text-cyberpunk-red tracking-wider mb-4">PROJECT_OVERVIEW</h4>
                        <p className="text-cyberpunk-text-dim leading-relaxed">
                          {selectedProject.longDescription}
                        </p>
                      </div>
                      
                      {/* Problem Statement */}
                      <div>
                        <h4 className="text-xl text-cyberpunk-red tracking-wider mb-4">PROBLEM_STATEMENT</h4>
                        <p className="text-cyberpunk-text-dim leading-relaxed">
                          {selectedProject.problem}
                        </p>
                      </div>
                      
                      {/* Solution */}
                      <div>
                        <h4 className="text-xl text-cyberpunk-red tracking-wider mb-4">SOLUTION</h4>
                        <p className="text-cyberpunk-text-dim leading-relaxed">
                          {selectedProject.solution}
                        </p>
                      </div>
                      
                      {/* Technologies */}
                      <div>
                        <h4 className="text-xl text-cyberpunk-red tracking-wider mb-4">TECHNOLOGIES</h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedProject.technologies.map((tech) => (
                            <span
                              key={tech}
                              className="px-3 py-1 text-sm border border-cyberpunk-red/30 text-cyberpunk-red bg-cyberpunk-red/5"
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      {/* Setup Instructions */}
                      <div>
                        <h4 className="text-xl text-cyberpunk-red tracking-wider mb-4">SETUP_INSTRUCTIONS</h4>
                        <div className="space-y-2 bg-cyberpunk-gray/20 p-4 border border-cyberpunk-red/30">
                          {selectedProject.setup.map((step, index) => (
                            <div key={index} className="flex items-start space-x-3">
                              <span className="text-cyberpunk-red">{index + 1}.</span>
                              <code className="text-cyberpunk-text text-sm">{step}</code>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Metrics */}
                      <div>
                        <h4 className="text-xl text-cyberpunk-red tracking-wider mb-4">METRICS & IMPACT</h4>
                        <div className="grid md:grid-cols-3 gap-4">
                          <div className="border border-cyberpunk-red/30 p-4">
                            <div className="text-cyberpunk-red text-lg">{selectedProject.metrics.performance}</div>
                            <div className="text-cyberpunk-text-dim text-sm">Performance</div>
                          </div>
                          
                          <div className="border border-cyberpunk-red/30 p-4">
                            <div className="text-cyberpunk-red text-lg">{selectedProject.metrics.impact}</div>
                            <div className="text-cyberpunk-text-dim text-sm">Impact</div>
                          </div>
                          
                          {selectedProject.metrics.users && (
                            <div className="border border-cyberpunk-red/30 p-4">
                              <div className="text-cyberpunk-red text-lg">{selectedProject.metrics.users}</div>
                              <div className="text-cyberpunk-text-dim text-sm">Users/Scale</div>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Action buttons */}
                      <div className="flex gap-4 pt-4">
                        {selectedProject.demoUrl && (
                          <motion.a
                            href={selectedProject.demoUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="flex-1 px-4 py-3 bg-cyberpunk-red text-cyberpunk-text text-center tracking-wider border border-cyberpunk-red hover:bg-transparent hover:text-cyberpunk-red transition-colors duration-300"
                          >
                            VIEW DEMO
                          </motion.a>
                        )}
                        
                        {selectedProject.githubUrl && (
                          <motion.a
                            href={selectedProject.githubUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="flex-1 px-4 py-3 border border-cyberpunk-red text-cyberpunk-red text-center tracking-wider hover:bg-cyberpunk-red hover:text-cyberpunk-text transition-colors duration-300"
                          >
                            VIEW CODE
                          </motion.a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

export default ProjectsSection;
