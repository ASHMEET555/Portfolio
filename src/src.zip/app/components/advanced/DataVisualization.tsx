'use client';

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface MetricData {
  timestamp: string;
  value: number;
  label: string;
}

interface SkillData {
  name: string;
  value: number;
  color: string;
}

const DataVisualization = () => {
  const [performanceData, setPerformanceData] = useState<MetricData[]>([]);
  const [skillData, setSkillData] = useState<SkillData[]>([]);
  const [activeMetric, setActiveMetric] = useState('performance');

  useEffect(() => {
    // Simulate real-time performance data
    const generatePerformanceData = () => {
      const data: MetricData[] = [];
      const now = Date.now();
      
      for (let i = 29; i >= 0; i--) {
        data.push({
          timestamp: new Date(now - i * 1000).toLocaleTimeString(),
          value: 60 + Math.random() * 40, // 60-100 range
          label: `T-${i}`
        });
      }
      
      return data;
    };

    // Initialize skill data
    const skills: SkillData[] = [
      { name: 'React/Next.js', value: 95, color: '#ff0000' },
      { name: 'Machine Learning', value: 92, color: '#ff3333' },
      { name: 'Three.js/WebGL', value: 88, color: '#ff6666' },
      { name: 'Node.js/Python', value: 90, color: '#ff9999' },
      { name: 'Cloud/DevOps', value: 85, color: '#ffcccc' }
    ];

    setPerformanceData(generatePerformanceData());
    setSkillData(skills);

    // Update performance data every second
    const interval = setInterval(() => {
      setPerformanceData(prev => {
        const newData = [...prev.slice(1)];
        newData.push({
          timestamp: new Date().toLocaleTimeString(),
          value: 60 + Math.random() * 40,
          label: `T-0`
        });
        return newData;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const metrics = [
    { id: 'performance', label: 'PERFORMANCE', unit: 'FPS' },
    { id: 'engagement', label: 'ENGAGEMENT', unit: '%' },
    { id: 'efficiency', label: 'EFFICIENCY', unit: 'Score' }
  ];

  return (
    <div className="w-full space-y-8">
      {/* Metric Selector */}
      <div className="flex flex-wrap gap-4 justify-center">
        {metrics.map((metric) => (
          <motion.button
            key={metric.id}
            onClick={() => setActiveMetric(metric.id)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-3 border transition-all duration-300 ${
              activeMetric === metric.id
                ? 'border-cyberpunk-red bg-cyberpunk-red/20 text-cyberpunk-red'
                : 'border-cyberpunk-red/30 text-cyberpunk-text-dim hover:border-cyberpunk-red/60'
            }`}
          >
            <div className="text-sm tracking-wider">{metric.label}</div>
            <div className="text-xs opacity-60">{metric.unit}</div>
          </motion.button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Real-time Performance Chart */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-cyberpunk-gray/20 border border-cyberpunk-red/30 p-6"
        >
          <h3 className="text-cyberpunk-red tracking-wider mb-6">
            REAL_TIME_METRICS
          </h3>
          
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <XAxis 
                  dataKey="timestamp" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#cccccc', fontSize: 10 }}
                  interval="preserveStartEnd"
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#cccccc', fontSize: 10 }}
                  domain={[0, 100]}
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#ff0000"
                  strokeWidth={2}
                  dot={false}
                  strokeDasharray="0"
                  filter="drop-shadow(0 0 6px #ff0000)"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-cyberpunk-red text-xl">
                {performanceData[performanceData.length - 1]?.value.toFixed(1) || '0.0'}
              </div>
              <div className="text-xs text-cyberpunk-text-dim">CURRENT</div>
            </div>
            <div>
              <div className="text-cyberpunk-red text-xl">
                {(performanceData.reduce((sum, d) => sum + d.value, 0) / performanceData.length).toFixed(1)}
              </div>
              <div className="text-xs text-cyberpunk-text-dim">AVERAGE</div>
            </div>
            <div>
              <div className="text-cyberpunk-red text-xl">
                {Math.max(...performanceData.map(d => d.value)).toFixed(1)}
              </div>
              <div className="text-xs text-cyberpunk-text-dim">PEAK</div>
            </div>
          </div>
        </motion.div>

        {/* Skills Distribution */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-cyberpunk-gray/20 border border-cyberpunk-red/30 p-6"
        >
          <h3 className="text-cyberpunk-red tracking-wider mb-6">
            SKILL_DISTRIBUTION
          </h3>
          
          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={skillData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  dataKey="value"
                  startAngle={90}
                  endAngle={-270}
                >
                  {skillData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3">
            {skillData.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-3 h-3 border border-cyberpunk-red/50"
                    style={{ backgroundColor: skill.color }}
                  />
                  <span className="text-sm text-cyberpunk-text">{skill.name}</span>
                </div>
                <span className="text-cyberpunk-red text-sm">{skill.value}%</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* System Status */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="bg-cyberpunk-gray/20 border border-cyberpunk-red/30 p-6"
      >
        <h3 className="text-cyberpunk-red tracking-wider mb-6">
          SYSTEM_STATUS
        </h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'CPU_USAGE', value: '67%', status: 'OPTIMAL' },
            { label: 'MEMORY', value: '4.2GB', status: 'NORMAL' },
            { label: 'NETWORK', value: '142ms', status: 'STABLE' },
            { label: 'UPTIME', value: '99.8%', status: 'EXCELLENT' }
          ].map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="text-center p-4 border border-cyberpunk-red/20 hover:border-cyberpunk-red/50 transition-colors duration-300"
            >
              <div className="text-2xl text-cyberpunk-red mb-2">{metric.value}</div>
              <div className="text-xs text-cyberpunk-text-dim mb-1">{metric.label}</div>
              <div className="text-xs text-green-400">{metric.status}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default DataVisualization;